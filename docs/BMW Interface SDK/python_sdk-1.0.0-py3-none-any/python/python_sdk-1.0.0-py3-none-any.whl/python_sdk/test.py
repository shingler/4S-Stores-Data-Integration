from python_sdk.sign.security_util import get_signature_dict

import json


if __name__ == "__main__":
    data = "{\"vin\":\"LBV3B1408FMB88808\"" \
           "}"

    accessKeySecretA = "MIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQCPk6oiR0kV/4tSwQZBnTAEN4teEdy+NyGpoOmNkN6puE0qPLaCcPfzt5lLdXn3QtOPtBeE56ZJCGC4ZIvspPZQWuHOJOrIbU9n1OpfuBeE3+iTvYYznmMTNgrwifbS75S+IefMGUx6hPF0lsDW5Cnz+8JTwcmj9h5zvnhsv1QSp5QBo+n1zjW1vXOUnYcaHE8J2JifCkcDqqBHsHUz49uyCVBT4zB8fhKP8FJLPoC4rxPENydlp3IVCD6gTrxSr5s5hwXOcxbvFfEqLft6xwjSb14pm9qQG1Vp4vQMmFaPTtdAD8yk+MqgEJvVxCGL/wtBxsxoCGIF71nXTOKW2rlNAgMBAAECggEATrkqig0IF9W8MK3BnmxvjYBfHD8zB+D2ximCpaqPTAPP257ae38xlSJQHT3WmCq+EYcvdiIF3PmI/tGynxh8LecG9J7tVOQKq+XkdINd8e9LeOZsFRV9QWVabjVXbqUKq42vqQseEfee5MxcA/eqwSqDjKUuyIYEgHYpVYc6s9byS+YiQq2uWhuu9Zjsu40PdVu9LhyuOS4oexJCxaOFs42mUYXtlysHL/6kvU3E94kJOC8Ki1mHIOnWgyBWgw36EzUOLovCSR1gx0kM65zUPFcGXPbJMtHHiFSSbmzDSr2bSoqKLoEdKLmSM7lBJusaWqI/0U4nO8x4LnUsE9W/SQKBgQDzx473wlj75NG6YjiWXO5Xss1W6F9XOjuFfs2G1vWOMgsBCPZup1QEKq9m6vaKwtBbalI9ehCFY7eBKCH5ai2mVwink61/sLvF3pjyzs65oCvNU2LgtlKsa5m+RVkvZoK4+dSb2hk033xlfzyDtklCeg5H18udUSZUInElBM1TcwKBgQCWxjJsvsdU6v65HdINRmgmMyh56PrIMRLgpIicqemepqASdUiNIm27u8ya35J6Si1sL2ASPYRbB1cKvt57yOpjjrSPE2PMaYNKZQfqs+h3XkvsroS7t2ySESLDOpB0vsE30hDPlTRzVFQ+raXjVkVmBtnTxezjaWY9GPF+cXQQPwKBgB1vJfMCU04uxaf0fhKhq+GI5EQvEHvuuwsWUWiLgeCmaC+6zk50A6/xG3aYviXo+dFf2Ag2OdJxRNHib5+200Y3UgMx0IwPYcy1YNBIait9jGxhOhoZyYeqAkk4BFm1zejZuXML9Wkt5s42e68HjnbpV9oS0zHuf2s/MVwf5U7DAoGAJgpVeJhdxHAR2nTKpWzJJDIuGSwN8epnv+PjT9uSxON3aZDLwEgadY45Xi3gUBhdA3mkfJWmyiy86koj6glUEdBUf/C9cjqA1IlPCQlhMpTJBSs29AGgU+4c3jLtdXcXWtUWRrl3ZU22f6XiP8xpcAd0d/js/qd+ExYy/9ryFJMCgYA04TrRNNFc4AQHrzX7R8c0VpAAFYZA3IhQZeLyOF3WwnHpEFZwz4T3ktQSmDNFRab4G2md8md4Ww88T1ASC4ASLWvPAXu9lU8gmvLrUFREmw4hmeFGPAKZP8OrS6KJu1aMFBNEPgqiS6T8Ie/eGMy97e8PPUWlGO9L544Seoh1UQ=="

    ori_data = {
        "DealerGroupCode": 'bmw_hxqc',
        "DealerEntityCode": 'HD420700',
        'AccessKeySecret': accessKeySecretA,
        'Action': 'G100910000',
        'SignatureMethod': 'SHA256withRSA',
        'Format': 'json',
        'Data': data,
    }


    sign_dict = get_signature_dict(ori_data)

    print(json.dumps(sign_dict))
    print(type(sign_dict))

    # url = "http://10.0.17.200:8080/bmw_hxqc/adapterInterface"
    # headers = {'Content-Type': 'application/json;charset=UTF-8'}
    # a = json.dumps(sign_dict)
    # # a="{\"SignatureVersion\":\"1.0\",\"Action\":\"G100910000\",\"Format\":\"json\",\"SignatureNonce\":\"b3509726-a2d9-4af3-aff2-602e74063e91\",\"Version\":\"v1\",\"DealerGroupCode\":\"bmw_hxqc\",\"Signature\":\"8ZV/Dbq4S1muwxG4P4Lw5SINpWI=\",\"DealerEntityCode\":\"HD420700\",\"SignatureMethod\":\"HMAC-SHA1\",\"Data\":\"{\\\"vin\\\":\\\"LBV3B1408FMB88808\\\"}\",\"AccessKey\":\"MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAhCmkf/0OSJOFBBcuPHoKAkVSx+zEdw9DyOWY4x5wjAumhx2irN7ytCY/VRVwF5gIysytQAd/0k0Je+6oVVaMx06p7UAIus4vSyIPi3bI7n9cFnFEopoRfqf8ZyUB4QdvgUS5e1Ptr+MOq1xyOiawMm3+QI1QnjPjw15mTtmY4ydpW4977FO2XyyTvvFsxiIpPKbdQJr0YjhCCT6zFedDnIPQVcXvlwDmLNMxF69+lC0kaUBSb9TnmemVEcaWOYYk8sytRaO2ojFtlv1EkeJqUwA6FDsqzQ81aqClvZg6m7Rt6BDBZEPilDSijFIQDk+JsUkpir4O4PT9no0LaHzqlwIDAQAB\",\"Timestamp\":\"2020-04-28T09:40:14Z\"}"
    # r = requests.post(url, data=a, headers=headers)
    # print(r.status_code)
    # print(r.text)


